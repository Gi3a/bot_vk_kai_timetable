/* ===================
	Scripts

	Project: Shef;
	Type: Scripts;
	Author: Gi3a;

=================== */


/* ===================
	Scripts && Jquery
=================== */

$(document).ready(function() {


/* === Default Settings === */

 	var curPage = location.href;
	var prevPage = sessionStorage.getItem('curPage');
	var hostPage = location.hostname;

	sessionStorage.setItem('curPage', curPage);
	sessionStorage.setItem('prevPage', prevPage);

/* === Set Nice select === */
	
	$('select:not(.ignore)').niceSelect();

/* === Set Color on Dividers Menu === */

	$(function() {
		$('.divider a').hover(function() {
			var rand = getRandomColor();
			$(this).css('background', rand);
			$(this).css('color', "#fff");
		}, function() {
			$(this).css('background', "transparent");
			$(this).css('color', "#666");
		});
	});

/* === Language Function === */


// Set Language as default
	if (!($.cookie('SSLANG'))) {
		var language = window.navigator ? (window.navigator.language ||
		window.navigator.systemLanguage ||
		window.navigator.userLanguage) : "ru";
		language = language.substr(0, 2).toLowerCase();
		if ((language != 'ru') || (language != 'en') || (language != 'cn') || (language != 'es')) {language = 'en';}
		$.cookie('SSLANG',language,{ path: '/' });
	}

// Set language as choosen
	$("a[data-globe]").click(function(){
		var language = $(this).attr('data-globe');
		$.cookie('SSLANG',language, { path: '/' });
		location.reload();
	});


/* === Get Upload File Image === */
	function readURL(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();
			reader.onload = function(e) {
				$('img[data-uploaded-img]').attr('src', e.target.result);
			}

				reader.readAsDataURL(input.files[0]);
			}
	}

		$('input[data-uploaded-img]').change(function() {
			$('img[data-uploaded-img]').show();
			readURL(this);
	});

/* === Get Random Color === */
	function getRandomColor() {
		var back = ["#ffd600","#f57921","#6caadb", "#c7b1d5", "#5dda7c", "#f55444"];
  		var rand = back[Math.floor(Math.random() * back.length)];
  		return rand;
	}
});