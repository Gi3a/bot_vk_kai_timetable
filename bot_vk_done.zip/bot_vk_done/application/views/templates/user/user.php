<div>
	<?php var_dump($this->route) ?>
</div>