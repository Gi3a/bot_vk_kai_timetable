<div class="page">
	<div class="block form__under">
		<span><h2><?php echo $lang['recovery'] ?></h2></span>
		<span> <i class="fas fa-undo-alt" style="color: #f06508;"></i> </span>
	</div>
	<div class="block">
		<form class="form" method="post" action="/recovery">
			<div class="form-block">
				<label class="form__label"><?php echo $lang['label_email'] ?></label>
				<input class="form__input" type="text" name="email">
			</div>
			<div class="form-block">
				<input class="form__submit" type="submit" value="<?php echo $lang['label_continue'] ?>">
			</div>
		</form>
	</div>
	<hr>
	<div class="block form__under">
		<span><?php echo $lang['label_already_have'] ?><a href="/login"><?php echo $lang['label_an_account'] ?>?</a></span>
	</div>
	<div class="block form__under">
		<span><?php echo $lang['label_join_or_login'] ?><br><?php echo $lang['label_agree_with'] ?><br>
		<a href="/legal/terms"><?php echo $lang['label_terms'] ?></a> Site <?php echo $lang['label_and'] ?><a href="/legal/privacy"><?php echo $lang['label_privacy'] ?></a>.</span>
	</div>
</div>