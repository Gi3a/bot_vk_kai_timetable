<div class="page">

	<?php if ($this->route['type'] == 'product'): ?>
		<!-- Join as User -->
		<div class="block form__under">
			<span> <h2><?=$lang['change'] ?></h2> </span>
			<span> <i class="fas fa-edit" style="color: orange;"></i> </span>
		</div>
		<div class="block">
			<form class="form" method="post" action="/change/<?=$this->route['type'] ?>/<?=$this->route['id'] ?>">
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_name']?></label>
					<input class="form__input" type="text" name="title" value="<?=$item[0]['title']?>">
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_category'] ?></label>
					<select name="category" class="form__input">
						<?php foreach ($categories as $key => $val): ?>
							<option
								value="<?=$val['title'] ?>"
								<?php if ($item[0]['category'] == $val['title']) echo 'selected'; ?>>
								<?=$lang[$val['title']] ?>
							</option>
						<?php endforeach; ?>

					</select>
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_sub_category'] ?></label>
					<input class="form__input" type="text" name="sub_category" value="<?=$item[0]['sub_category']?>">
				</div>
				<div class="form-block">


					<label class="form__label"><?=$lang['dish_photo'] ?></label>

					<span class="upload-file"><i class="fas fa-camera"></i></span>
					<input class="form__input" data-uploaded-img type="file" name="img" title="Выберите фото">
				</div>
				<div class="form-block form-file">
					<img data-uploaded-img src="/upload/item/<?=$this->route['id']; ?>.jpg">
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_description'] ?></label>
					<textarea class="form__input" name="description" rows="8"><?=$item[0]['description'] ?></textarea>
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_weight'] ?></label>
					<input class="form__input" type="text" name="weight" value="<?=$item[0]['weight']?>">
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['specify_city'] ?></label>
					<input class="form__input" type="text" name="city" value="<?=$item[0]['address'] ?>">
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_price'] ?></label>
					<input class="form__input" type="text" name="cost" value="<?=$item[0]['cost'] ?>">
				</div>
				<div class="form-block">
					<input class="form__submit" type="submit" value="<?=$lang['label_continue'] ?>">
				</div>
			</form>
		</div>
	<?php else: ?>
		<?php $this->redirect('404'); ?>
	<?php endif; ?>
</div>
