<div class="page">

	<?php if ($this->route['type'] == 'product'): ?>
		<!-- Join as User -->
		<div class="block form__under">
			<span> <h2><?=$lang['add_product'] ?></h2> </span>
			<span> <i class="fas fa-plus" style="color: orange;"></i> </span>
		</div>
		<div class="block">
			<form class="form" method="post" action="/add/product">
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_name'] ?></label>
					<input class="form__input" type="text" name="title">
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_category'] ?></label>
					<select name="category" class="form__input">
						<?php foreach ($categories as $key => $val): ?>
							<option value="<?=$val['title'] ?>" > <?=$lang[$val['title']] ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_sub_category'] ?></label>
					<input class="form__input" type="text" name="sub_category">
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_photo'] ?></label>
					<span class="upload-file"><i class="fas fa-camera"></i></span>
					<input class="form__input" data-uploaded-img type="file" name="img" title="Выберите фото">
				</div>
				<div class="form-block form-file">
					<img data-uploaded-img >
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_description'] ?></label>
					<textarea class="form__input" name="description" rows="8"></textarea>
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_weight'] ?></label>
					<input class="form__input" type="text" name="weight">
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['specify_city'] ?></label>
					<input class="form__input" type="text" name="city">
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_price'] ?></label>
					<input class="form__input" type="text" name="cost">
				</div>
				<div class="form-block">
					<label class="form__label"><?=$lang['dish_date_expiration'] ?></label>
					<select name="date_expiration" class="form__input">
						<option value="daily"> <?=$lang['package_daily'] ?></option>
						<option value="weekly"> <?=$lang['package_weekly'] ?></option>
					</select>
				</div>
				<div class="form-block">
					<input class="form__submit" type="submit" value="<?=$lang['label_continue'] ?>">
				</div>
			</form>
		</div>
	<?php else: ?>
		<?php $this->redirect('404'); ?>
	<?php endif; ?>
</div>




