<div class="items">
    <?php foreach ($products as $val): ?>
        <div class="item" id="<? echo $val['id'] ?>">
            <div class="item__top" style="background-image: url('/upload/item/<?=$val['id']?>.jpg')">
                
            </div>

            <div class="item__bottom">
                
                <h3 class="item__title"><? echo $val['title'] ?></h3>
                <span class="item__description"><? echo $val['description'] ?></span>
                
                <div class="item__spans">
                    <span class="item__cost"><i>₽</i> <? echo $val['cost'] ?></span>
                    <span class="item__views"><i class="far fa-eye"></i> <? echo $val['views'] ?></span>
                    <span class="item__rating"><i class="far fa-star"></i> <? echo $val['rating'] ?></span>
                </div>
            </div>
            
        </div>
    <?php endforeach; ?>
</div>



<div class="numbering">
    <?php echo $pagination; ?>
</div>