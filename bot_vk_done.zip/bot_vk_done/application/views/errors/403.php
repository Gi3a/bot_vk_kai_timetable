<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">

        <title>403 | Shef</title>
    
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="/public/img/favicon/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/public/img/favicon/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/public/img/favicon/favicon-16x16.png">
        <link rel="manifest" href="/public/img/favicon/site.webmanifest">
        <link rel="mask-icon" href="/public/img/favicon/safari-pinned-tab.svg" color="#29c1eb">
        <meta name="msapplication-TileColor" content="#0ccaff">
        <meta name="theme-color" content="#ffffff">

        <link rel="stylesheet" href="/public/css/font.css">
        <link rel="stylesheet" href="/public/css/style.css">
        <link rel="stylesheet" href="/public/css/error.css">
    </head>
    <body>
        <main>
            <div class="error">
                <img src="/public/img/gifs/background.gif">
                <a href="/" class="error__title">
                    <p><b>403</b></p>
                    <p>Access denied</p>
                    <p>Доступ запрещен</p>
                </a>
            </div>
        </main>
    </body>
</html>