<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">

        <title><?php echo $title; ?></title>

        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="/public/img/favicon/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/public/img/favicon/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/public/img/favicon/favicon-16x16.png">
        <link rel="manifest" href="/public/img/favicon/site.webmanifest">
        <link rel="mask-icon" href="/public/img/favicon/safari-pinned-tab.svg" color="#29c1eb">
        <meta name="msapplication-TileColor" content="#0ccaff">
        <meta name="theme-color" content="#ffffff">
        
        <!-- CSS -->
        <link rel="stylesheet" type="text/css" href="/public/css/font.css">
        <link rel="stylesheet" type="text/css" href="/public/css/swal.css">
        <!-- CSS -->
		<link rel="stylesheet" type="text/css" href="/public/css/style.css">
        <link rel="stylesheet" type="text/css" href="/public/css/head.css">
        <link rel="stylesheet" type="text/css" href="/public/css/mid.css">
        <link rel="stylesheet" type="text/css" href="/public/css/foot.css">
        <link rel="stylesheet" type="text/css" href="/public/css/nice-select.css">
        
        <!-- JS -->
        <script src="/public/js/jquery.js"></script>
        <script src="/public/js/ajax.js"></script>
        <script src="/public/js/script.js"></script>
        <script src="/public/js/swal.js"></script>
        <script src="/public/js/font.js"></script>
        <script src="/public/js/nice-select.js"></script>
    </head>
    <body>
        <header>
            <?php require_once 'application/views/header/nav.tpl'; ?>
            <?php require_once 'application/views/header/nav-script.tpl'; ?>
        </header>
        <main>
            <?php echo $content; ?>
        </main>
        <footer>
            <?php require_once 'application/views/footer/foot.tpl'; ?>
            <?php require_once 'application/views/footer/foot-script.tpl'; ?>
        </footer>
    </body>
</html>
