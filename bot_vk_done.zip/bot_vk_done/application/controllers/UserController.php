<?php

namespace application\controllers;

use application\core\Controller;
use application\lib\Pagination;

use application\models\Main;
use application\models\Auth;


class UserController extends Controller {

	/* --- Profile PATH --- */
	// Profile Action //
	public function userAction(){
		$vars = [
			'lang' => $this->lang,
		];
		$this->view->render('User | Shef', $vars);
	}

	/* --- Auth PATH --- */
	// Join Action //
	public function joinAction() {
		$auth = new Auth;
		if (($_SERVER['REQUEST_METHOD'] == 'POST') && (!empty($_POST))) {
			// Validate route
			// Validate post
			if(!$auth->validate(['email','login','name', 'password'], $_POST))
				$this->view->message('error', $auth->title, $auth->message);
			// Existence Email
			else if($auth->isEmailExist($_POST['email']))
				$this->view->message('error', 'E-mail уже зарегестрирован');
			// Exsitence Login
			else if($auth->isLoginExist($_POST['login']))
				$this->view->message('error','Логин занят', '');
			// Join User Func
			$joinStatus = $this->model->join($_POST);
			// Check if User Func = true
			if (($joinStatus != 0) or (!empty($joinStatus))) {
				$this->view->teleport(
					'success', // Type
					'join/confirm', // URL
					'Регистрация прошла успешна', // Title
					'На ваш e-mail адрес было отправлено письмо с подтверждением вашего аккаунта' // Text
				);
			} else { $this->view->message('error', 'Произошла ошибка', 'Мы уже работаем над ней'); } 

		}

		$vars = [
			'lang' => $this->lang,
		];
		$this->view->render($vars['lang']['join_user'].' | Shef', $vars);
	}
	// Login Action //
	public function loginAction() {
		$auth = new Auth;

		// If !empty $_SESSION[]

		// If !empty $_HASH_SESSION

		if (($_SERVER['REQUEST_METHOD'] == 'POST') && (!empty($_POST))) {
			if(!$auth->validate(['password'], $_POST)){
				$this->view->message('error', $auth->title, $auth->message); }

			elseif( !$auth->isUserExist($_POST['login']) ){
				$this->view->message('error', 'Проверьте данные', 'Пользователь не найден'); }

			elseif(!$auth->checkPasswordUser($_POST['login'],$_POST['password'])){
				$this->view->message('error', 'Проверьте данные', 'E-mail, логин или пароль указан неверно'); }

			elseif(!$auth->checkStatusUser($_POST['login'])){
				$this->view->message('info', 'Проблемы со входом', $auth->error); }

			//Update date_visit
			$auth->updateDateVisit($_POST['login']);
			// Save $_HASH_SESSION Func
			$loginStatus = $this->model->login($_POST['login']);
			$this->view->location('main');
		}
		$vars = [
			'lang' => $this->lang,
		];
		$this->view->render($vars['lang']['login'].' | Shef', $vars);
	}
	// Confirm Action //
	public function confirmAction() {
		$auth = new Auth;

		if (($_SERVER['REQUEST_METHOD'] == 'POST') && (!empty($_POST)))
		{
			$token = $_POST['token'];

			if(!$auth->validate(['token'], $_POST))
			{
				$this->view->message('error', $auth->title, $auth->message);
			}

			$codeUserName = $auth->checkCodeUser($token);
			if ($codeUserName[0]['status'] == 'inactive')
			{
				if(!$codeUserName){
					$this->view->message('error', 'Проверьте данные', 'Пользователь не найден');
				}
				else{
					$this->model->activateUser($token);
					$this->model->login($codeUserName[0]['login']);
					$this->view->teleport(
						'success',
						'main',
						"Поздравляем ". $codeUserName[0]['name']."!",
						'Регистрация завершена успешна'
					);
				}
			} else {
				$this->view->message('error', 'Ошибка', 'Аккаунт уже активирован');
			}

		}


		$vars = [
			'lang' => $this->lang,
		];
		$this->view->render('Подтверждение регистрации | Shef', $vars);
	}
	// Recovery Actions //
	public function recoveryAction(){
		$auth = new Auth;
		if (($_SERVER['REQUEST_METHOD'] == 'POST') && (!empty($_POST))) {
			if(!$auth->validate(['email'], $_POST)){
				$this->view->message('error', $auth->title, $auth->message); }

			elseif(!$auth->isEmailExist($_POST['email'])){
				$this->view->message('error', 'Проверьте данные', 'Пользователь не найден'); }

			elseif(!$auth->checkStatusUser($_POST['email'])){
				$this->view->message('info', 'Проблемы со входом', $auth->error); }

			else{
				$this->model->recovery($_POST);
				$this->view->teleport('success','login', 'Восстановление пароля сброшен на ваш e-mail адрес');
			}
		}
		$vars = [
			'lang' => $this->lang,
		];
		$this->view->render('Восстановление доступа | Shef', $vars);
	}

		// Reset Action //
	public function resetAction() {
		$auth = new Auth;
		//
		if(!$auth->checkCodeUser($this->route['token'])) {
			$this->view->redirect('login');
		}
		if (($_SERVER['REQUEST_METHOD'] == 'POST') && (!empty($_POST))) {
			if(!$auth->validate(['password'], $_POST)){
				$this->view->message('error', $this->model->error);
			}
			$this->model->reset($this->route['token'], $_POST['password']);
			$this->view->teleport('success','login', $this->model->error);
		}

		$vars = [
			'lang' => $this->lang,
		];
		$this->view->render('Сбрось пароля | Shef', $vars);
	}


	/* Exit Action */
	public function exitAction() {
		$this->model->logout();
		$this->view->redirect('login');
	}

}