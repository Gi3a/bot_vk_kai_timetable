<?php

namespace application\controllers;

use application\core\Controller;
use application\lib\Pagination;

use application\models\Main;
use application\models\Item;

class MainController extends Controller {

	
	public function mainAction() {
		$item = new Item;

		$type = 'product';

		// Get paginations
		$pagination = new Pagination($this->route, $item->countItems($type));
		// Variables
		$vars = [
			'pagination' => $pagination->get(),
			'products' => $item->getItems($this->route, $type),
			'lang' => $this->lang,
		];

		$this->view->render('Site - песочница для разработки', $vars);
	}
	
	public function reportAction(){
		if (($_SERVER['REQUEST_METHOD'] == 'POST') && (!empty($_POST)))
		{
			if (!$this->model->validate(['description'], $_POST)){ $this->view->message('error', $this->model->error); } 
			else{
				$report_status = $this->model->report($_POST);
				if (!$report_status)
					$this->view->message('error', $this->lang['report_error']);
				else
					$this->view->message('success', $this->lang['report_thanks']);
			}
		}
	}

}