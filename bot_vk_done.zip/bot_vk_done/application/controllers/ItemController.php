<?php

namespace application\controllers;

use application\core\Controller;
use application\lib\Pagination;

use application\models\Main;
use application\models\Auth;
use application\models\File;


class ItemController extends Controller {

	public function myItemsAction()
	{	
		// Get type
		$type = substr($this->route['type'], 0,-1);

		// Check Type
		if (($type != 'order') && ($type != 'product') && ($type !='offer'))
			$this->view->redirect(404);

		// Get paginations
		$pagination = new Pagination($this->route, $this->model->countItems($type, $_SESSION['user']['login']));
		// Variables
		$vars = [
			'pagination' => $pagination->get(),
			'products' => $this->model->getItems($this->route, $type, $_SESSION['user']['login']),
			'lang' => $this->lang,
		];

		// Rendering Page
		$this->view->render($vars['lang']['my_products'].' | Shef', $vars);
	}

	public function addAction()
	{	
		// Need to save Image
		$file = new File;
		
		// Get type
		$type = $this->route['type'];

		// Check Type
		if (($type != 'order') && ($type != 'product') && ($type !='offer'))
			$this->view->redirect(404);

		// Check Post
		if (($_SERVER['REQUEST_METHOD'] == 'POST') && (!empty($_POST)))
		{
			// Validate Info
			if(!$this->model->validate(['title', 'category', 'sub_category', 'description', 'weight', 'date_expiration' , 'city', 'cost'], $_POST))
				$this->view->message('error','', $this->model->error);

			// Check access to add item
			if (!$this->model->accessToAdd($_SESSION['user']['login'], $_SESSION['user']['package'], $this->route['type']) )
				$this->view->message('error', 'Вы достигли лимита', 'Можете приобрести пакет');

			// Check not null image
			if (!empty($_FILES)) {

				// Check size and extension image
				if (!$file->imgValidate($_POST, 'add')) {
					$this->view->message('error', $file->error);
				}
				else{
					// Add item
					$item = $this->model->addItem($_POST, 'product');
					if (($item != 0) or (!empty($item))){
						// Save image
						$img = $file->saveImg($_FILES['img']['tmp_name'], $item, 'items');


						// Redirect
						$this->view->teleport('success', 'add/'.$type, 'Ваша продукция добавлена успешно!');
					}
				}
			}
			// If null, then error
			if ($item == 0)
				$this->view->message('error', 'Ошибка', 'Произошла ошибка при добавлении, попробуйте позже');
		}

		// Variable
		$vars = [
			'lang' => $this->lang,
			'categories' => $this->model->getCategories(),
		];

		// Render
		$this->view->render($vars['lang']['add_'.$type].' | Shef', $vars);
	}

	public function changeAction()
	{
		$file = new File;

		// Get Info
		$id = $this->route['id'];
		$type = $this->route['type'];

		// Check Type
		if (($type != 'order') && ($type != 'product') && ($type !='offer'))
			$this->view->redirect(404);

		// Get item
		$item = $this->model->getItemInfo($id, $type);

		// Exsist
		if(!$item)
			$this->view->errorCode(404);

		// Check Post
		if (($_SERVER['REQUEST_METHOD'] == 'POST') && (!empty($_POST)))
		{
			// Validate Info
			if(!$this->model->validate(['title', 'category', 'sub_category', 'description', 'weight', 'city', 'cost'], $_POST))
				$this->view->message('error','', $this->model->error);

			// If photo changed > we change it, or not
			if (!empty($_FILES) && ($_FILES['img']['size'] != 0))
			{
				// Check size and extension image
				if (!$file->imgValidate($_POST, 'add')) {
					$this->view->message('error', $file->error);
				}
				else{
					// Change item
					$this->model->changeItem($id, $_POST, 'product');

					// Save image
					$img = $file->saveImg($_FILES['img']['tmp_name'], $id, 'offers');

					// Redirect
					$this->view->teleport('success', 'add/product', 'Ваша продукция изменена!');
				}
			} else {
				// Change item
				$this->model->changeItem($id, $_POST, 'product');
				$this->view->teleport('success', 'add/product', 'Ваша продукция изменена!');
			}
		}

		$vars = [
			'item' => $item,
			'categories' => $this->model->getCategories(),
			'lang' => $this->lang,
		];
		// If exsists?
		// If access?

		$this->view->render($vars['lang']['change'].' | Shef', $vars);
	}

	public function removeAction()
	{
		// Get Info
		$id = $this->route['id'];
		$type = $this->route['type'];

		// Get item
		$item = $this->model->getItemInfo($id, $type);
		// Type
		if (($type != 'order') && ($type != 'product') && ($type !='offer'))
			$this->view->redirect(404);

		// Exsist
		if(!$item)
			$this->view->errorCode(404);

		// Removing and unlink photo
		$result = $this->model->removeItem($id, $type, $_SESSION['user']['login']);

		if ($result == true)
			$this->view->message('success','Успешно удалено', '');
		else
			$this->view->message('error','', $this->model->error);


		//Redirect
		$this->view->redirect('my/products');
	}

}