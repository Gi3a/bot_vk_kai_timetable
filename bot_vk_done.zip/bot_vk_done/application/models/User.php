<?php

namespace application\models;

use application\core\Model;


class User extends Model {

	public $error;

	// Generate Token for Join Func
	public function generateToken(){
		return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyz', 10)), 0, 10);
	}
	// Join Func
	public function join($post){
		
		list($name, $surname) = explode(" ", $post['name']);

		$token = $this->generateToken();

		$params = [
			'id' => '0',
			'login' => trim(htmlspecialchars($post['login'])),
			'email' => trim(htmlspecialchars($post['email'])),
			'name' => trim(htmlspecialchars($name)),
			'surname' => trim(htmlspecialchars($surname)),
			'password' => trim(htmlspecialchars(password_hash(trim($_POST['password']), PASSWORD_BCRYPT))),
			'package' => 'default',
			'role' => 'user',
			'status' => 'inactive',
			'phone' => NULL,
			'buffer_address' => NULL,
			'buffer_token' => trim(htmlspecialchars($token)),
			'date_visit' => date("Y-m-d H:i"),
			'date_registration' => date("Y-m-d H:i"),
		];
		$this->db->query('INSERT INTO users VALUES (:id, :login, :email, :name, :surname, :password, :package, :role, :status, :phone, :buffer_address, :buffer_token, :date_visit, :date_registration)', $params);

		mail($post['email'], 'Регистрация прошла успешно', 'Code: '.$token.' or http://shef/join/confirm/'.$token);
		return $this->db->lastInsertId();
	}
	// Login Func
	public function login($login){
		$params = [
			'email' => trim(htmlspecialchars($login)),
			'login' => trim(htmlspecialchars($login)),
		];
		$data = $this->db->row('SELECT * FROM users WHERE email = :email OR login = :login', $params);
		$_SESSION['user'] = $data[0];
	}
	// Confirm Func
	public function activateUser($buffer_token){
		$params = [
			'buffer_token' => trim(htmlspecialchars($buffer_token)),
			'status' => 'active'
		];
		$this->db->query('UPDATE users SET status = :status, buffer_token = "" WHERE buffer_token = :buffer_token', $params);
	}
	// Recovery
	public function recovery($post){
		$token = $this->generateToken();

		$params = [
			'email' => trim(htmlspecialchars($post['email'])),
			'buffer_token' => trim(htmlspecialchars($token)),
		];
		$this->db->query('UPDATE users SET buffer_token = :buffer_token WHERE email = :email', $params);

		mail($post['email'], 'Восстановление пароля', 'Подтверждение http://shef/reset/'.$token);
		return $this->db->lastInsertId();
	}
	// Reset
	public function reset($token, $password){
		$params = [
			'buffer_token' => trim(htmlspecialchars($token)),
			'password' => trim(htmlspecialchars(password_hash($password, PASSWORD_BCRYPT))),
		];

		$this->db->query('UPDATE users SET buffer_token = "", password = :password WHERE buffer_token = :buffer_token', $params);
		return $this->error = 'Новый пароль установлен';
	}


	// Exit Func
	public function logout(){
		// Update Info Last Visit
		unset($_SESSION['user']);
	}
}