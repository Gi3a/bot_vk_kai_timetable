<?php

namespace application\models;

use application\core\Model;

class Item extends Model {

	public $error;

	public function validate($input,$post){
		$rules = [
			'title' => [
				'pattern' => '#^[а-яА-ЯёЁa-zA-Z0-9_.,! -]{2,150}$#u',
				'message' => 'Название указано неверно (от 2 до 150 символов)',
			],
			'description' => [
				'pattern' => '#^[а-яА-ЯёЁa-zA-z0-9_.,!()%: -/\r/\n]{2,150}$#u',
				'message' => 'Описание указано неверно (от 3 до 150 символов)',
			],
			'weight' => [
				'pattern' => '#^[0-9]{1,50}$#u',
				'message' => 'Вес указан неверно, только цифры',
			],
			'city' => [
				'pattern' => '#^[а-яА-ЯёЁa-zA-Z0-9 , -]{2,150}$#u',
				'message' => 'Название города указано неверно (от 2 до 150 символов)',
			],
			'category' => [
				'pattern' => '#^[а-яА-ЯёЁa-zA-z |/_]{2,50}$#',
				'message' => 'Выберите категорию',
			],
			'sub_category' => [
				'pattern' => '#^[а-яА-ЯёЁa-zA-Z0-9_.,! -]{2,150}$#u',
				'message' => 'Подкатегория указана неверно (от 2 до 150 символов)',
			],
			'date_expiration' => [
				'pattern' => '#^[а-яА-ЯёЁa-zA-z |/_]{2,50}$#',
				'message' => 'Выберите срок',
			],
			'cost' => [
				'pattern' => '#^[0-9]{1,40}$#',
				'message' => 'Цена указана неверно (от 1 до 40 символов)',
			],

		];
		foreach ($input as $val) {
			if (!isset($post[$val]) or !preg_match($rules[$val]['pattern'], $post[$val])) {
				$this->error = $rules[$val]['message'];
				return false;
			}
		}
		return true;
	}

	public function getCategories(){
		return $this->db->row('SELECT title FROM categories');
	}

	public function addItem($post, $type){
		if ($_POST['date_expiration'] == 'weekly') {$date_expiration = 7;$priority=1;}

		// elseif($_POST['date_expiration'] == 'hour') {$date_expiration = 1;$priority=1.5;}
		// elseif($_POST['date_expiration'] == 'couple') {$date_expiration = 1;$priority=1.5;}
		// elseif($_POST['date_expiration'] == 'three') {$date_expiration = 1;$priority=1.5;}

		elseif($_POST['date_expiration'] == 'daily'){$date_expiration = 1;$priority=2;}
		else return 0;
		// elseif($_POST['date_expiration'] == 'monthly'){$date_expiration = 31;$priority=1.5;}
		// elseif($_POST['date_expiration'] == 'halfy'){$date_expiration = 183;$priority=1.5;}
		// elseif($_POST['date_expiration'] == 'anualy'){$date_expiration = 365;$priority=2;}


		$date_expiration = date("Y-m-d H:i", strtotime($date_expiration.'days'));

		$params = [
			'id' => '0',
			'author' => trim(htmlspecialchars($_SESSION['user']['login'])),
			'category' => trim(htmlspecialchars($post['category'])),
			'sub_category' => trim(htmlspecialchars($post['sub_category'])),
			'title' => trim(htmlspecialchars($post['title'])),
			'description' => trim(htmlspecialchars($post['description'])),
			'weight' => trim(htmlspecialchars($post['weight'])),
			'cost' => trim(htmlspecialchars($post['cost'])),
			'views' => 0,
			'type' => trim(htmlspecialchars($type)),
			'rating' => $priority,
			'date_added' => date("Y-m-d H:i"),
			'date_ended' => $date_expiration,
			'address' => trim(htmlspecialchars($post['city'])),
			// Photo?
		];
		$this->db->query('INSERT INTO items VALUES (:id,:author, :category,:sub_category, :title, :description, :weight, :cost, :views, :type, :rating, :date_added, :date_ended, :address)', $params);
		return $this->db->lastInsertId();
	}

	public function changeItem($id, $post, $type)
	{
		$params = [
			'id' => trim(htmlspecialchars($id)),
			'type' => trim(htmlspecialchars($type)),
			'author' => $_SESSION['user']['login'],
			'category' => trim(htmlspecialchars($post['category'])),
			'sub_category' => trim(htmlspecialchars($post['sub_category'])),
			'weight' => trim(htmlspecialchars($post['weight'])),
			'title' => trim(htmlspecialchars($post['title'])),
			'description' => trim(htmlspecialchars($post['description'])),
			'cost' => trim(htmlspecialchars($post['cost'])),
			'address' => trim(htmlspecialchars($post['city'])),
		];
		$this->db->query('UPDATE items SET category = :category, sub_category = :sub_category, title = :title, description = :description, weight = :weight, cost = :cost, address = :address WHERE id = :id AND type = :type AND author = :author', $params);
	}

	public function accessToAdd($author, $package, $type)
	{
		$params = [
			'author' => trim(htmlspecialchars($author)),
			'package' => trim(htmlspecialchars($package)),
			'type' => trim(htmlspecialchars($type)),
		];
		$query = $this->db->row("
			SELECT packages.count_item, COUNT(items.id)
			FROM packages, items
			WHERE packages.title = :package AND items.author = :author AND items.type = :type", $params);
		
		if ($query[0]['count_item'] == NULL)
			return true;

		$package_count = $query[0]['count_item'];
		$author_count = $query[0]['COUNT(items.id)'];
		$result = $package_count - $author_count;

		if ($result > 0)
			return true;
		else
			return false;
	}


	public function accessUserToItem($id,$type)
	{
		$params = [
			'id' => trim(htmlspecialchars($id)),
			'author' => trim(htmlspecialchars($_SESSION['user']['login'])),
			'type' => trim(htmlspecialchars($type))
		];
		return $this->db->column('SELECT id FROM items WHERE id = :id AND author = :author AND type = :type', $params);	
	}

	public function getItemInfo($id, $type)
	{
		$params = [
			'id' => trim(htmlspecialchars($id)),
			'author' => trim(htmlspecialchars($_SESSION['user']['login'])),
			'type' => trim(htmlspecialchars($type))
		];
		return $this->db->row('SELECT category, sub_category, title, description, weight, cost, address, author FROM items WHERE id = :id AND author = :author AND type = :type', $params);	
	}

	public function countItems($type, $author = '')
	{
		$params = [		
			'type' => trim(htmlspecialchars($type))
		];

		if(!empty($author))
			$params = array_merge($params, array('author' => trim(htmlspecialchars($author))));

		if(!empty($author))
			return $this->db->column('SELECT COUNT(id) FROM items WHERE type = :type AND author = :author', $params);
		else
			return $this->db->column('SELECT COUNT(id) FROM items WHERE type = :type', $params);

	}

	public function getItems($route, $type, $author = '')
	{
		$max = 10;
		$params = [
			'max' => $max,
			'start' => ((($route['page'] ?? 1) - 1) * $max),
			'type' => trim(htmlspecialchars($type)),
		];

		if(!empty($author))
			$params = array_merge($params, array('author' => trim(htmlspecialchars($author))));

		if(!empty($author))
			$items = $this->db->row('SELECT id, author, category, sub_category, title, description, weight, cost, rating, views FROM items WHERE type = :type AND author = :author ORDER BY id DESC LIMIT :start, :max', $params);
		else
			$items = $this->db->row('SELECT id, author, category, sub_category, title, description, weight, cost, rating, views FROM items WHERE type = :type ORDER BY id DESC LIMIT :start, :max', $params);

		return $items;
	}

	public function removeItem($id, $type, $author)
	{
		$params = [
			'id'=> trim(htmlspecialchars($id)),
			'author' => trim(htmlspecialchars($author)),
			'type' => trim(htmlspecialchars($type))
		];

		$this->db->column('DELETE FROM items WHERE id = :id AND author = :author AND type = :type', $params);

		if(file_exists('upload/item/'.$id.'.jpg')){
			unlink('upload/item/'.$id.'.jpg');
		}else{
			$this->error = 'Фотографии не найдено';
			return false;
		}
		return true;
	}

	
}