<?php

namespace application\models;

use application\core\Model;
use Aws\S3\Exception\S3Exception;


class File extends Model {

	var $image;
	var $image_type;

	public function imgValidate($post,$type){

	$types = array('image/jpeg', 'image/png');

		if ($_FILES['img']['error'] and $type =='add') {
			$this->error = 'Фото не выбрано';
			return false;
		} else if ($_FILES['img']['size'] > 5000000) { // 5 мегабайт
			$this->error = 'Фото слишком большое большое > 5 мегабайт';
			return false;
		} elseif (!in_array($_FILES['img']['type'], $types)) {
				$this->error = '.JPG || .PNG';
			return false;
		}
		return true;
	}

	public function load($filename) {
		$image_info = getimagesize($filename);
		$this->image_type = $image_info[2];
		if( $this->image_type == IMAGETYPE_JPEG ) {
			$this->image = imagecreatefromjpeg($filename);
		} elseif( $this->image_type == IMAGETYPE_PNG ) {
			$this->image = imagecreatefrompng($filename);
		}
	}
	public function save($filename, $image_type=IMAGETYPE_JPEG, $compression=75, $permissions=null) {
		if( $image_type == IMAGETYPE_JPEG ) {
			imagejpeg($this->image,$filename,$compression);
		}elseif( $image_type == IMAGETYPE_PNG ) {
			imagepng($this->image,$filename);
		}
		if( $permissions != null) {
			chmod($filename,$permissions);
		}
	}
	public function output($image_type=IMAGETYPE_JPEG) {
		if( $image_type == IMAGETYPE_JPEG ) {
			imagejpeg($this->image);
		}elseif( $image_type == IMAGETYPE_PNG ) {
			imagepng($this->image);
		}
	}
	public function getWidth() {
		return imagesx($this->image);
	}
	public function getHeight() {
		return imagesy($this->image);
	}
	public function resizeToHeight($height) {
		$ratio = $height / $this->getHeight();
		$width = $this->getWidth() * $ratio;
		$this->resize($width,$height);
	}
	public function resizeToWidth($width) {
		$ratio = $width / $this->getWidth();
		$height = $this->getheight() * $ratio;
		$this->resize($width,$height);
	}
	public function scale($scale) {
		$width = $this->getWidth() * $scale/100;
		$height = $this->getheight() * $scale/100;
		$this->resize($width,$height);
	}
	public function resize($width,$height) {
		$new_image = imagecreatetruecolor($width, $height);
		imagecopyresampled($new_image, $this->image, 0, 0, 0, 0, $width, $height, $this->getWidth(), $this->getHeight());
		$this->image = $new_image;
	}

	public function saveImg($path, $id, $type){
		if (!empty($_FILES['img'])) {


			$file = $_FILES['img']; // Getting Img
	 		// File Details
	 		$name = '1.jpg'; // Название изначальное
	 		$tmp_name = $file['tmp_name']; // Темп файла

	 		// Extension
	 		$ex = $file['type'];
			$extension = explode('.', $name); // Расширение файла
			$extension = strtolower(end($extension));

			// Temp Details
			$key = $id; // Сгенерированый уникальная строчка
			$tmp_file_name = "{$key}.{$extension}"; // Даём новое имя
			$tmp_file_path = "upload/item/{$tmp_file_name}";

			$this->load($tmp_name);
			$this->resizeToWidth(700);
			$this->save($tmp_file_path);

			// Move the file
			// if ($ex == 'image/jpeg') {$file = imagecreatefromjpeg($tmp_name);}
			// elseif($ex == 'image/png'){$file = imagecreatefrompng($tmp_name);}
			// $new_file = imagejpeg($file, $tmp_file_path, 75);
			// move_uploaded_file($new_file, $tmp_file_path);

		}
	}

}