<?php

return [
	'host' => 'localhost',
	'name' => 'v91729ya_shef',
	'user' => 'v91729ya_shef',
	'password' => 'UQZeG8bZ',
];