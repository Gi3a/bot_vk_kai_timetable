<?php

return [
	// Main Controller
	'tagline' => 'A great online platform for buying / selling food',

	'search' => 'Search',
	'input_address' => 'Enter shipping address',

	'recommended' => 'Recommended',
	'top' => 'Top',
	'home' => 'Home',

	'city' => 'City',

	'report' => 'Report',
	'report_info' => 'Describe the issue or share your opinion',
	'report_send' => 'Send',
	'report_thanks' => 'Thanks for your feedback',
	'report_error' => 'An error has occurred, please try again later',


	'lang' => 'Language',
	'more' => 'More',
	'news' => 'News',
	'agreement' => 'Agreement',
	'about' => 'About',

	'reset' => 'Password reset',
	'recovery' => 'Access recovery',
	'confirm' => 'Confirm registration',
	'login' => 'Login',
	'join_user' => 'Join',
	'join_driver' => 'Become a driver',
	'join_company' => 'Company registration',

	'specify_city' => 'Specify city',
	'city_not_found' => 'City not found',

	/* User Controller */

	// Join Page
	'label_token' => 'Code from e-mail',
	'label_email' => 'E-mail',
	'label_new_login' => 'Create a username (login)',
	'label_login' => 'Login',
	'label_name' => 'Name and surname',
	'label_new_password' => 'Create a password',
	'label_password' => 'Password',
	'label_continue' => 'Continue',
	'label_already_have' => 'Already have ',
	'label_create' => 'Create ',
	'label_an_account' => 'an account',
	'label_join_or_login' => 'By registering or logging in',
	'label_agree_with' => 'You agree with',
	'label_terms' => 'Terms of Service',
	'label_and' => 'and',
	'label_privacy' => 'Privacy Policy.',
	'label_login' => 'Enter email or login',

	'label_forgot_password' => 'Forgot password',


	'home_page' => 'My account',

	'cart' => 'Cart',
	'cart_view' => 'View all',

	'liked' => 'Liked',
	'liked_view' => 'View all',

	'my' => 'Added',
	'my_products' => 'Product',
	'my_orders' => 'Orders',
	'my_offers' => 'Offers',
	'my_routes' => 'Routes',

	'my_requests' => 'Requests', 

	'my_noti' => 'Notifications',
	'my_balance' => 'Balance',

	'exit' => 'Exit',

	//Item Controller
	'add_product' => 'Add product',
	'add_order' => 'Create order',
	'add_offer' => 'Make offer',

	'change' => 'Change',
	'remove' => 'Remove',

	// Cateegories
	'bakery' => 'Bakery',
	'breakfast' => 'Breakfasts',
	'dessert' => 'Desserts',
	'drink' => 'Drinks',
	'salad' => 'Salads',
	'sauce' => 'Sauces',
	'snack' => 'Snacks',
	'soup' => 'Soups',
	'dinner' => 'Dinners',
	'lunch' => 'Lunches',
	'main_course' => 'Main courses',


	// Create Product Page
	'dish_name' => 'Dish name',
	'dish_category' => 'Select a category',
	'dish_sub_category' => 'Write a subcategory',
	'dish_photo' => 'Upload a photo',
	'dish_description' => 'Description of the dish',
	'dish_weight' => 'Indicate weight in grams',
	'dish_keywords_example' => 'For example: chocolate, meat, waffles',
	'dish_keywords' => 'Specify specific words',
	'dish_price' => 'Price',
	'dish_date_expiration' => 'Duration',

	'package_daily' => 'Day (12 hours | priority high)',
	'package_weekly' => 'Week (7 days | priority default)',
	'package_monthly' => 'Month (Package small bussines)',
	'package_halfy' => 'Half year (Package company)',
	'package_anually' => '1 year (Package corporation)',

	// Cart Actions
	'cart_add' => 'Add',
	

	// Messages Errors
	'message_error_limit_label' => 'Error limit',
	'message_error_limit_text' => 'Text',

	// Message Success
	'message_success_add_label' => 'Added successfully',
	'message_success_add_text' => 'Added successfully',

];