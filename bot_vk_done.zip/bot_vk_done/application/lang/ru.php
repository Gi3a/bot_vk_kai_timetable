<?php

return [
	//Main Controller
	'tagline' => 'Крупная онлайн платформа для купле/продажи еды',

	'search' => 'Поиск',
	'input_address' => 'Укажите адрес доставки',

	'recommended' => 'Рекомендации',
	'top' => 'Топ',
	'home' => 'Главная',

	'city' => 'Город',

	'report' => 'Отзыв/Проблема',
	'report_info' => 'Опишите проблему или поделитесь своим мнением',
	'report_send' => 'Отправить',
	'report_thanks' => 'Спасибо за отзыв',
	'report_error' => 'Произошла ошибка, попробуйте позднее',

	'lang' => 'Язык',
	'more' => 'Еще',
	'news' => 'Новости',
	'agreement' => 'Соглашения',
	'about' => 'О платформе',

	'reset' => 'Сброс пароля',
	'recovery' => 'Восстановление доступа',
	'confirm' => 'Подтверждение регистрации',
	'login' => 'Вход',
	'join_user' => 'Регистрация',
	'join_driver' => 'Стать драйвером',
	'join_company' => 'Регистрация компании',

	'specify_city' => 'Укажите город',
	'city_not_found' => 'Город не найден',


	//User Controller
	'label_token' => 'Код из e-mail',
	'label_email' => 'E-mail',
	'label_new_login' => 'Придумайте логин',
	'label_login' => 'Логин',
	'label_name' => 'Имя и фамилия',
	'label_new_password' => 'Придумайте пароль',
	'label_password' => 'Пароль',
	'label_continue' => 'Продолжить',
	'label_already_have' => 'Уже есть ',
	'label_create' => 'Создать ',
	'label_an_account' => 'аккаунт',
	'label_join_or_login' => 'Зарегистрировавшись или войдя в систему',
	'label_agree_with' => 'Вы соглашаетесь с',
	'label_terms' => 'Условиями использования',
	'label_and' => 'и',
	'label_privacy' => 'политикой конфиденциальности',
	'label_login' => 'Введите почту или логин',

	'label_forgot_password' => 'Забыли пароль',



	'home_page' => 'Моя страница',

	'cart' => 'Корзина',
	'cart_view' => 'Посмотреть корзину',

	'liked' => 'Понравилось',
	'liked_view' => 'Все понравившиеся',

	'my' => 'Добавленное',
	'my_products' => 'Продукция',
	'my_orders' => 'Заказы',
	'my_offer' => 'Предложения',
	'my_routes' => 'Доставки',

	'my_requests' => 'Заявки', 

	'my_noti' => 'Уведомления',
	'my_balance' => 'Баланс',

	'exit' => 'Выйти',

	//Item Controller
	'add_product' => 'Добавить продукцию',
	'add_order' => 'Создать заказ',
	'add_offer' => 'Сделать предложение',
	'change' => 'Изменить',
	'remove' => 'Убрать',

	// Categories
	// Cateegories
	'bakery' => 'Выпечка',
	'breakfast' => 'Завтраки',
	'dessert' => 'Десерты',
	'drink' => 'Напитки',
	'salad' => 'Салаты',
	'sauce' => 'Соусы',
	'snack' => 'Закуски',
	'soup' => 'Супы',
	'dinner' => 'Обеды',
	'lunch' => 'Ланчи',
	'main_course' => 'Главные блюда',


	// Create Product Page
	'dish_name' => 'Название блюда',
	'dish_category' => 'Выберите категорию',
	'dish_sub_category' => 'Назовите подкатегорию',
	'dish_photo' => 'Загрузите фото',
	'dish_description' => 'Описание блюда',
	'dish_weight' => 'Укажите вес в граммах',
	'dish_keywords_example' => 'Например: шоколадный, мясной, вафли',
	'dish_keywords' => 'Укажите ключевые слова',
	'dish_price' => 'Цена',
	'dish_date_expiration' => 'Период размещения',

	'package_daily' => 'День (12 часов | приоритет высокий)',
	'package_weekly' => 'Неделя (7 дней | приоритет обычный)',
	'package_monthly' => 'Месяц (Пакет малый бизнес)',
	'package_halfy' => 'Полгода (Пакет Компания)',
	'package_anually' => 'Год (Пакет корпорация)',


	// Cart Actions
	'cart_add' => 'Добавить',
		

	// Messages Errors
	'message_error_limit_label' => 'Ошибка лимита',
	'message_error_limit_text' => 'Текст',

	// Message Success
	'message_success_add_label' => 'Добавлено успешно',
	'message_success_add_text' => 'Добавлено успешно',

];