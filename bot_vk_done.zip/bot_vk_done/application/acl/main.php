<?php

return [
	'all' => [
		'main',
		'report',
	],
	'user' => [
		'main',
		'report',
	],
	'admin' => [
		'main',
		'report',
	],
];

?>