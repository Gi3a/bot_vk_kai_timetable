<?php

return [
	'all' => [
		'user',
		'join',
		'login',
		'confirm',
		'recovery',
		'reset',
	],
	'user' => [
		'user',
		'exit',
	],
	'admin' => [
		'user',
		'exit',
	],
];

?>