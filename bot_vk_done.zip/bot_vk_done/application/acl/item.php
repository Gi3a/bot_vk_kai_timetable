<?php

return [
	'all' => [
		//
	],
	'user' => [
		'myItems',
		'add',
		'change',
		'remove',
	],
	'admin' => [
		'myItems',
		'add',
		'change',
		'remove',
	],
];

?>