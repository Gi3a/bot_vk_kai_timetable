<?php

return [
	'all' => [
		//
	],
	'user' => [
		//
	],
	'admin' => [
		//
	],
];

?>